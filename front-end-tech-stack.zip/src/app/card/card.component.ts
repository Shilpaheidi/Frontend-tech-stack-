import { Component, Input } from '@angular/core';
import { Ticket } from '../interface/ticket.model';
import { EditCardDialogComponent } from '../edit-card-dialog/edit-card-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent {
  @Input() ticket!: Ticket;

  constructor(private dialog: MatDialog,private apiservice:ApiService) { 
  }

  openEditDialog(): void {
    const dialogRef = this.dialog.open(EditCardDialogComponent, {
      width: '400px',
      data: { ...this.ticket }
    });

    dialogRef.componentInstance.ticketUpdated.subscribe((updatedTicket: Ticket) => {
      // Update the local ticket object with the edited data
      this.ticket = updatedTicket;
      // You can also update your service with the updated data here if needed
           
    });
  }


  ngOnInit(){}
  
}
