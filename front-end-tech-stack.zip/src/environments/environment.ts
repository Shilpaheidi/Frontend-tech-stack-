
const base_URL = `http://localhost:3000/`
export const environment = {
  production: true,


  getAllCards:`${base_URL}getAllRecords`,

  insertTickets:`${base_URL}insert-tickets`,

  updateTickets:`${base_URL}update-tickets`

};







